Downloader  oriented product line R&D personnel, Mainfeatures:
1. Download images
2. Upload images
3. Erase partition
4. Merge images
5. Extract images
6. generate partition file